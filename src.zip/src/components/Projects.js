import { Container, Row, Col, Tab, Nav } from "react-bootstrap";
import { ProjectCard } from "./ProjectCard";
import projImg1 from "../assets/img/codepen.jpg";
import projImg2 from "../assets/img/food1.jpg";
import projImg3 from "../assets/img/images.jpg";
import projImg4 from "../assets/img/covid.jpg";
import projImg5 from "../assets/img/cyber.jpg";
import projImg6 from "../assets/img/face.jpg";
import projImg7 from "../assets/img/roundrobin.png";
import projImg8 from "../assets/img/payroll.jpg";
import projImg9 from "../assets/img/railway.jpg";







import colorSharp2 from "../assets/img/color-sharp2.png";
import 'animate.css';
import TrackVisibility from 'react-on-screen';

export const Projects = () => {

  const projects = [
    {
      title: "Simple Codepen Application",
      description: "The best place to build, test, and discover front-end code.CodePen is a social development environment for front-end designers and developers. Build and deploy a website, show off your work, build test cases to learn and debug, and find inspiration.",
      imgUrl: projImg1,
    },
    {
      title: "Food Fire Application",
      description: "Order food from the confort of your home, we show the latest restaurants available in your city, with all the details. Pick a dish, add to cart, place order, get delivered.",
      imgUrl: projImg2,
    },
    {
      title: "Youtube from React",
      description: " Dive into the world of modern web development as you navigate through video listings, watch your favorite content, and witness the responsiveness of this React-driven YouTube experience. Whether you're a React enthusiast or just curious about how YouTube could be built with this powerful library, this clone is a great place to explore and learn. ",
      imgUrl: projImg3,
    },
    {
      title: "A Solution to Covid-19: Detection & Recognition of faces with mask",
      description: "This system is designed to serve the purpose of detecting the presence or absence of face-mask and also to recognize faces of the employees of the organization despite the presence of face masks and detect if the person belongs to the organization or not.",
      imgUrl: projImg4,
    },
    {
      title: "A solution towards controlling cyberbullying on social media",
      description: "Detects cyberbullying on users’ posts and comments and further, their level of toxicity.Besides, in case of highly toxic content shared, it also warns the user and/or temporarily suspends their account for the next two hours as a penalty. The system",
      imgUrl: projImg5,
    },
    {
      title: "Face detection using machine learning",
      description: "A deep neural network that is trained to recognize faces by being fed a large dataset of images of faces. The deep neural network learns to recognize patterns in the images, such as the shape of the eyes, nose, and mouth, and it can then use this knowledge to recognize faces in new images.",
      imgUrl: projImg6,
    },
    {
      title: "Implementation Of Round Robin Scheduling Algorithm in Java",
      description: "Round Robin algorithm is a CPU scheduling algorithm. It is also used in network schedulers. It is especially designed for time sharing system. It is also known as time slicing scheduling algorithm. This project is implemented in java",
      imgUrl: projImg7,
    },
    {
      title: "Payroll Management System",
      description: "A project that can empower companies by streamlining and automatically carrying out the processes involved in payroll such as working out take home pay and taxes – saving time for the employer and reducing the number of errors.",
      imgUrl: projImg8,
    },
    {
      title: "Railway Reservation System using Queues",
      description: "A deep neural network that is trained to recognize faces by being fed a large dataset of images of faces. The deep neural network learns to recognize patterns in the images, such as the shape of the eyes, nose, and mouth, and it can then use this knowledge to recognize faces in new images.",
      imgUrl: projImg9,
    },
  ];

  return (
    <section className="project" id="projects">
      <Container>
        <Row>
          <Col size={12}>
            <TrackVisibility>
              {({ isVisible }) =>
              <div className={isVisible ? "animate__animated animate__fadeIn": ""}>
                <h2>Projects</h2>
                <Tab.Container id="projects-tabs" defaultActiveKey="first">
                  <Nav variant="pills" className="nav-pills mb-5 justify-content-center align-items-center" id="pills-tab">
                    <Nav.Item>
                      <Nav.Link eventKey="first">Tab 1</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="second">Tab 2</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="third">Tab 3</Nav.Link>
                    </Nav.Item>
                  </Nav>
                  <Tab.Content id="slideInUp" className={isVisible ? "animate__animated animate__slideInUp" : ""}>
                    <Tab.Pane eventKey="third">
                      <Row>
                        {
                          projects.map((project, index) => {
                            return (
                              <ProjectCard
                                key={index}
                                {...project}
                                />
                            )
                          })
                        }
                      </Row>
                    </Tab.Pane>
                    <Tab.Pane eventKey="second">
                      <p>"Embark on a journey of innovation! Explore my diverse projects, ranging from web development to AI. Each one is a testament to creativity, problem-solving, and the pursuit of excellence. Dive in and discover the exciting world of my endeavors!"
                      </p>
                    </Tab.Pane>
                    <Tab.Pane eventKey="first">
                      <p>Discover innovation in action! Explore my projects to see creativity, problem-solving, and technology come together. From web development to machine learning, each project showcases a unique blend of skills and ideas. Dive in, explore, and get inspired!</p>
                    </Tab.Pane>
                  </Tab.Content>
                </Tab.Container>
              </div>}
            </TrackVisibility>
          </Col>
        </Row>
      </Container>
      <img className="background-image-right" src={colorSharp2}></img>
    </section>
  )
}
